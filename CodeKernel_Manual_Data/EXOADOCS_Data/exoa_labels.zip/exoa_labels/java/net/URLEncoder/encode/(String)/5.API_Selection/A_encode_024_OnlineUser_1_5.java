public class A{
	//...
	public static void main(){
		protocol.put(String.valueOf(com.crack.ProtocolConstant.URL), java.net.URLEncoder.encode(url));
	}
}