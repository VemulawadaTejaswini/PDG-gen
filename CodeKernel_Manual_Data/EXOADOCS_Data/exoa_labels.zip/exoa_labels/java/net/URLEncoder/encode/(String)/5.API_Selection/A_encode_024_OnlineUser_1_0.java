public class A{
	//...
	public static void main(){
		protocol.put(String.valueOf(com.crack.ProtocolConstant.UID), java.net.URLEncoder.encode(name));
	}
}