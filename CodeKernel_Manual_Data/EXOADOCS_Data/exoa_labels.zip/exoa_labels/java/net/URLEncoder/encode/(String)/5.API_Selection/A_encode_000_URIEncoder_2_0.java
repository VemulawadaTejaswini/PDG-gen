public class A{
	//...
	public static void main(){
		String str = args[i];
		//...
		System.out.println("encode(" + str + ")=" + encode(str));
	}
}