public class A{
	public static String commEncode (String toEncode){
		//...
		return encode(toEncode);
	}
}