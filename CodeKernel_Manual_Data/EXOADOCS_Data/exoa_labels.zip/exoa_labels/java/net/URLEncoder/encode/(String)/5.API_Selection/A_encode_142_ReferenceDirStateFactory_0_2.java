public class A{
	//...
	public static void main(){
		String strobj=java.net.URLEncoder.encode((refAddr.getType()+"_"+refAddr.getContent()).replace('.','^'));
	}
}