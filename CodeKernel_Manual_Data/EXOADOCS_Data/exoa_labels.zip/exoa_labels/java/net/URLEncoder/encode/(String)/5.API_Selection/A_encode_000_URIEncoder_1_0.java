public class A{
	//...
	public static void main(){
		return encode(str.getBytes(encoding));
	}
}