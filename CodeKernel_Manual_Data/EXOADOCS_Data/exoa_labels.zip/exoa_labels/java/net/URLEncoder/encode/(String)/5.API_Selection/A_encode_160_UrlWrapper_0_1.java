public class A{
	//...
	public static void main(){
		query += encode(key) + "=" + encode(queryMap.get(key));
	}
}