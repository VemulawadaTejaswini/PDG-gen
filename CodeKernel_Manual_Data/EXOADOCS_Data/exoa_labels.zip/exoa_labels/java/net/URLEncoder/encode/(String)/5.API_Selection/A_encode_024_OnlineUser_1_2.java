public class A{
	//...
	public static void main(){
		protocol.put(String.valueOf(com.crack.ProtocolConstant.UAREA), java.net.URLEncoder.encode(area));
	}
}