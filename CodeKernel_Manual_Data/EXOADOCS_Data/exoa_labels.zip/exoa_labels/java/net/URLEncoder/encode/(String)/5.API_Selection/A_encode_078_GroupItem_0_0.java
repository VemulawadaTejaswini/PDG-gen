public class A{
	//...
	public static void main(){
		return java.net.URLEncoder.encode(groupid);
	}
}