public class A{
	static public String encode(String text) throws LRException{
		return encode(text,URL);
	}
}