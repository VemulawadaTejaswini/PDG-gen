public class A{
	//...
	public static void main(){
		protocol.put(String.valueOf(com.crack.ProtocolConstant.UPAGE), java.net.URLEncoder.encode(page));
	}
}