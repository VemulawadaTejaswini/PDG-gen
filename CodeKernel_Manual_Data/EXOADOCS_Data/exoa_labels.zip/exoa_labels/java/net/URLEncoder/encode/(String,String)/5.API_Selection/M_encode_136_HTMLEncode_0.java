public class A{
	public final static String encode(String s){
		return encode(s, "\n");
	}
}