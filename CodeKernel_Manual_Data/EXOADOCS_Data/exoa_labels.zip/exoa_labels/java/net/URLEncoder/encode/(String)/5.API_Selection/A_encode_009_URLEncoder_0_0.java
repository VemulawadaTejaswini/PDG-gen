public class A{
	public static String encode(String str){
		return java.net.URLEncoder.encode(str);
	}
}