public class A{
	public static String encode(String str) {
		//...
		String encoding = Encoding.getDefault().getJavaEncoding();
		//...
		s = encode(str, encoding);
	}
}