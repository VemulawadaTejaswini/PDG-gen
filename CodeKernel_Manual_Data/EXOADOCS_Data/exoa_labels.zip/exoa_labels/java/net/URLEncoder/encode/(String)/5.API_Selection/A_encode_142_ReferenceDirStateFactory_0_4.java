public class A{
	//...
	public static void main(){
		strfactory=java.net.URLEncoder.encode(FACTORY_TAG+"null");
	}
}