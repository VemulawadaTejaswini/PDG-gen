public class A{
	//...
	public static void main(){
		strname=java.net.URLEncoder.encode(name.toString().replace('.','^'));
	}
}