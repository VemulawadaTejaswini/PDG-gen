public class A{
	//...
	public static void main(){
		protocol.put(String.valueOf(com.crack.ProtocolConstant.UNICK), java.net.URLEncoder.encode(nickname));
	}
}