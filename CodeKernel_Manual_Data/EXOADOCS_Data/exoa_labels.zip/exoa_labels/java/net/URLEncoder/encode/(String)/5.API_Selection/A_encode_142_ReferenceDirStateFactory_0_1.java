public class A{
	//...
	public static void main(){
		String strclass=java.net.URLEncoder.encode(CLASS_TAG+ref.getClassName().replace('.','^'));
	}
}