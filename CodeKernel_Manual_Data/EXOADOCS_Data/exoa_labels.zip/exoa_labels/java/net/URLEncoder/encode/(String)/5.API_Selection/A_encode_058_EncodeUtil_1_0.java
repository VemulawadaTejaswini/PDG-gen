public class A{
	//...
	public static void main(){
		return new String(new BASE64Encoder().encode(s.getBytes()));
	}
}