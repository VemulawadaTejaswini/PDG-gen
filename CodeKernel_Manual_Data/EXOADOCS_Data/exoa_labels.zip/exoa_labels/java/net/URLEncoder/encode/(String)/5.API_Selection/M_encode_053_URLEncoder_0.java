public class A{
	public String encode(String pValue) {
		return java.net.URLEncoder.encode(pValue);
	}
}