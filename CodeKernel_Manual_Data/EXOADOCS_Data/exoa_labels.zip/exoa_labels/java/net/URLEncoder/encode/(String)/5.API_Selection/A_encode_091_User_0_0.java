public class A{
	//...
	public static void main(){
		return java.net.URLEncoder.encode(name)+ProtocolConstant.SPACE+java.net.URLEncoder.encode(nickname)+ProtocolConstant.SPACE+state+ProtocolConstant.SPACE+o;
	}
}