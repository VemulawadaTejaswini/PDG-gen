public class A{
	//...
	public static void main(){
		String strlocation=java.net.URLEncoder.encode(LOCATION_TAG+ref.getFactoryClassLocation());
	}
}