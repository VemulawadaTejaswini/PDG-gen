public class A{
	public static String encode(String s) {
		//...
		return encode(s, "UTF-8");
	}
}