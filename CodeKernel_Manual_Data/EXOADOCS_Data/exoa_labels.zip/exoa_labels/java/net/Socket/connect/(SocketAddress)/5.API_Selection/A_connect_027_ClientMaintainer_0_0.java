public class A{
	//...
	public static void main(){
		Socket connectTo = new Socket();
		connectTo.connect(this.connectToSocket);
	}
}