public class A{
	//...
	public static void main(){
		Socket nsSocket = new Socket();
		//...
		nsSocket.connect(nsServerSocket.getLocalSocketAddress());
	}
}