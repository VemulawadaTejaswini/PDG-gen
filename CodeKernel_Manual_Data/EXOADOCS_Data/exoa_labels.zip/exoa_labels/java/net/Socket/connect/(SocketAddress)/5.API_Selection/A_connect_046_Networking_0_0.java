public class A{
	//...
	public static void main(){
		Socket socket = null;
		//...
		socket.connect(message.getTarget());
	}
}