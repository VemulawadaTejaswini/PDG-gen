public class A{
	//...
	public static void main(){
		InputStream input;
		//...
		return loadFromXML(input);
	}
}