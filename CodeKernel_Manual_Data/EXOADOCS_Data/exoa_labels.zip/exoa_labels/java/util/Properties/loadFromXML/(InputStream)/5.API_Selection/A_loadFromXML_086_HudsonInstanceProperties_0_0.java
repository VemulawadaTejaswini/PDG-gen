public class A{
	//...
	public static void main(){
		loadFromXML(properties.getInputStream());
	}
}