public class A{
	private void loadProperties(InputStream preferences_input_stream) {
		//...
		this.loadFromXML(preferences_input_stream);
	}
}