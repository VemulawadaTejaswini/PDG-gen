public class A{
	//...
	public static void main(){
		Properties pluginpro=new Properties();
		//...
		pluginpro.loadFromXML(tmpjar.getInputStream(tmpman));
	}
}