public class A{
	//...
	public static void main(){
		this.properties.loadFromXML(propertiesPath.openStream());
	}
}