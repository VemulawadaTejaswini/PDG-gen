public class A{
	//...
	public static void main(){
		Driver d = null;
		//...
		Properties info = new Properties();
		//...
		return d.connect(url,info);
	}
}