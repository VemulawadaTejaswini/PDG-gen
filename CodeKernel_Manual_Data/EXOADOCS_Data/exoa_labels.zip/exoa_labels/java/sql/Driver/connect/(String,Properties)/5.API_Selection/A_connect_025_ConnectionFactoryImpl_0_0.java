public class A{
	//...
	public static void main(){
		final Driver driver = (Driver) c.newInstance();
		return driver.connect(connectUrl, properties);
	}
}