public class A{
	public Connection connect(String url, Properties properties) throws SQLException {
		//...
		return super.connect(url, properties);
	}
}