public class A{
	public Connection connect(String arg0, Properties arg1) throws SQLException {
		return this.driver.connect(arg0, arg1);
	}
}