public class A{
	//...
	public static void main(){
		Statement stmt;
		//...
		int [] updateCounts = stmt.executeBatch();
	}
}