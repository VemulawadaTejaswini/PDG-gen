public class A{
	//...
	public static void main(){
		executeBatch();
	}
}