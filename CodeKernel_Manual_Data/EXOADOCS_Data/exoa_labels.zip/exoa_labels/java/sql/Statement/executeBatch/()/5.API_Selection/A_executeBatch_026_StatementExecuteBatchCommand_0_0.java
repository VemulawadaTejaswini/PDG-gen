public class A{
	//...
	public static void main(){
		Statement stmt = (Statement)target;
		//...
		return stmt.executeBatch();
	}
}