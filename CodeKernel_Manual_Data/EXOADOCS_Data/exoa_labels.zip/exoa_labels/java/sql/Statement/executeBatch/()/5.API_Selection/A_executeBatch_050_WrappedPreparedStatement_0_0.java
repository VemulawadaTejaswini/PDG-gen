public class A{
	//...
	public static void main(){
		return this.obj.executeBatch();
	}
}