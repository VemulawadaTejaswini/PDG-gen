public class A{
	//...
	public static void main(){
		int[] answer = myRawResourceComponent().executeBatch();
	}
}