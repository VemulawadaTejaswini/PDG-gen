public class A{
	public int[] executeBatch() throws java.sql.SQLException {
		return this.obj.executeBatch();
	}
}