public class A{
	//...
	public static void main(){
		stmts[i].executeBatch();
	}
}