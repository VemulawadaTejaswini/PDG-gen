public class A{
	//...
	public static void main(){
		getStatement().executeBatch();
	}
}