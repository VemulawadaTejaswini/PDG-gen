public class A{
	//...
	public static void main(){
		this.getStmt().executeBatch();
	}
}