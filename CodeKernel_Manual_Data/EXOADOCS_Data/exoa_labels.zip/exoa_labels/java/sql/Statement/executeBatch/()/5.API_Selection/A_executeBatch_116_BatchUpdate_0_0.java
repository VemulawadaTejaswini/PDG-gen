public class A{
	//...
	public static void main(){
		Statement  stmt = null;
		//...
		int[] updtcount = stmt.executeBatch();
	}
}