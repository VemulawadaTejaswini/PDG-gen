public class A{
	//...
	public static void main(){
		return this.getTarget().executeBatch();
	}
}