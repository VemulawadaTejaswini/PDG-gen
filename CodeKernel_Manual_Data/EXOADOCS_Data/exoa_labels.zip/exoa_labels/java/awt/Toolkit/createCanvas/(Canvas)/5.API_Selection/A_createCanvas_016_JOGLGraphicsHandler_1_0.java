public class A{
	//...
	public static void main(){
		interactionDependency = createCanvas(currentMLSceneGraphDependency);
	}
}