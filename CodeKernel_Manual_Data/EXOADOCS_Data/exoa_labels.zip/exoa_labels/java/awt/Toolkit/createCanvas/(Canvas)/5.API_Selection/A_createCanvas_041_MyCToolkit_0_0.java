public class A{
	public CanvasPeer createCanvas(Canvas canvas) {
		if (canvas == null)return super.createCanvas(canvas);
	}
}