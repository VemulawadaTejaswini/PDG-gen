public class A{
	//...
	public static void main(){
		interaction = createCanvas(currentMLSceneGraph);
	}
}