public class A{
	public CanvasPeer createCanvas(Canvas canvas) {
		//...
		peer = super.createCanvas(canvas);
	}
}