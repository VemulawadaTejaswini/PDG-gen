public class A{
	public CanvasPeer createCanvas(Canvas target) {
		return asSun().createCanvas(target);
	}
}