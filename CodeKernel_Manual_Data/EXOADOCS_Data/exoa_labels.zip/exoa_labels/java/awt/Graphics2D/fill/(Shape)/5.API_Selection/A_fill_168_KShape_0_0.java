public class A{
	public void paint(Graphics2D gx){
		//...
		gx.fill(m_shape);
	}
}