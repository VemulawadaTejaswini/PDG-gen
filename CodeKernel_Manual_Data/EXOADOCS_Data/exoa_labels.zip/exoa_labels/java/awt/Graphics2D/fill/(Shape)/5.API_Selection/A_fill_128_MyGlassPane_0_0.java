public class A{
	//...
	public static void main(){
		Graphics2D graphics2d = (Graphics2D)g;
		//...
		graphics2d.fill(rect);
	}
}