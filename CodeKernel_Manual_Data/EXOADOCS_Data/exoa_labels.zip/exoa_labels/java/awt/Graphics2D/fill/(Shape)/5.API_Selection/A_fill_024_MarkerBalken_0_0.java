public class A{
	//...
	public static void main(){
		Graphics2D g2 = (Graphics2D) g;
		//...
		case BALKEN_RECTANGLE:Shape shape = new Rectangle2D.Double(x - xu / 2, Math.min(y1, y2), xu,Math.abs(y1 - y2));
		g2.fill(shape);
	}
}