public class A{
	//...
	public static void main(){
		Graphics2D g2 = (Graphics2D) g;
		Shape sh;
		//...
		g2.fill(sh);
	}
}