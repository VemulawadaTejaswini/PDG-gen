public class A{
	public void draw(Graphics2D g){
		//...
		g.fill(this.rect);
	}
}