public class A{
	//...
	public static void main(){
		Graphics2D g2 = (Graphics2D) g;
		//...
		Shape shape = new Rectangle2D.Double(x - xu / 2, y - yu / 2, xu, yu);
		g2.fill(shape);
	}
}