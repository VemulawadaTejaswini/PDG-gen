public class A{
	//...
	public static void main(){
		Graphics2D fillG = NapkinUtil.lineGraphics(g, 1);
		fillG.fill(shape);
	}
}