public class A{
	public void render(Graphics2D g) {
		//...
		g.fill(shape);
	}
}