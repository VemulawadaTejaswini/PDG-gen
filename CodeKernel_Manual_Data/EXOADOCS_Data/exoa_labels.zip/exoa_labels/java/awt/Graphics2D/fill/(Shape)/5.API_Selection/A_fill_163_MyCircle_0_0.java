public class A{
	//...
	public static void main(){
		Graphics2D g2d = (Graphics2D)g;
		//...
		g2d.fill(circle);
	}
}