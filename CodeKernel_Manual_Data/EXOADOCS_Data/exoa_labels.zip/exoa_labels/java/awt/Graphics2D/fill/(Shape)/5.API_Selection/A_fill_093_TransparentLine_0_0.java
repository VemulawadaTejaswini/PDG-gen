public class A{
	public void draw(Graphics2D g2d){
		//...
		g2d.fill(ellipse[0]);
	}
}