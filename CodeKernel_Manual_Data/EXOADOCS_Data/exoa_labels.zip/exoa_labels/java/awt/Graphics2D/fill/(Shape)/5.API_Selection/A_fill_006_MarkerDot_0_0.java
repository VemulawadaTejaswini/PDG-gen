public class A{
	//...
	public static void main(){
		Graphics2D g2 = (Graphics2D) g;
		//...
		g2.fill(shape);
	}
}