public class A{
	public void drawShape(Graphics2D g2d) {
		//...
		g2d.fill(getShape());
	}
}