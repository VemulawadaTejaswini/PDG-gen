public class A{
	public SetOrigin(java.awt.Frame parent, GameData _data) {
		super(parent, true, null, _data, new java.util.Properties());
		initComponents();
		pack();
	}
}