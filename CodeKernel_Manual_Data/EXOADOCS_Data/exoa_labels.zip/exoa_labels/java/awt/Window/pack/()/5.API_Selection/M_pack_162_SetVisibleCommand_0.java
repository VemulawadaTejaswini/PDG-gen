public class A{
	public void execute(){
		if (init instanceof Window){
			((Window) init).pack();
		}
		init.setVisible(true);
	}
}