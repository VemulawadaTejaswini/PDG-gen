public class A{
	//...
	public static void main(){
		((JFrame)containers[0]).pack();
	}
}