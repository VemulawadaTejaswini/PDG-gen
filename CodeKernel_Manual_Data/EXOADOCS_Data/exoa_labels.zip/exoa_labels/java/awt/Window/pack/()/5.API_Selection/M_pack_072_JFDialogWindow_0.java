public class A{
	public void init() {
		pack();
		setCenter();
		setVisible(true);
	}
}