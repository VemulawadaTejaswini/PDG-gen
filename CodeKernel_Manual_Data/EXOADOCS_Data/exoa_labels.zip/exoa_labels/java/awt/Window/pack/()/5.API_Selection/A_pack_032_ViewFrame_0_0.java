public class A{
	//...
	public static void main(){
		ViewFrame.this.pack();
	}
}