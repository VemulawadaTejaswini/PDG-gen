public class A{
	//...
	public static void main(){
		((Window) init).pack();
	}
}