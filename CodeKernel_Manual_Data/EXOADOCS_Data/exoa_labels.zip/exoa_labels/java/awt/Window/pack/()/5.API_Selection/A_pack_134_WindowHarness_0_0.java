public class A{
	//...
	public static void main(){
		getFrame().pack();
	}
}